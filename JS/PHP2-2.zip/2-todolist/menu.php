<nav class="menu">
    <ul>
        <li><a href="index.php">List</a></li>
        <li><a href="add.php">Add</a></li>
        <li><a href="remove.php">Remove</a></li>
    </ul>
</nav>