var iNumber = getInteger(1, 10, "Choose a number");
document.write("<p>Chosen number : " + iNumber + "</p>");

document.write("<p>Chosen number : " + getInteger(10, 100, "Choose a number") + "</p>");